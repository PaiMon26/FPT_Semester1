#include <stdio.h>
#include <math.h>

void minMax(int n){
	int min, max, digit;
	
	digit = n % 10;
    min = max = digit;
    n = n / 10;
    
    while (n > 0) {
        digit = n % 10;
        n = n / 10;
        
        if (digit > max) {
            max = digit;
        }
        
        if (digit < min) {
            min = digit;
        }
    }
	
	printf("Minimum digit = %d\n", min);
	printf("Maximum digit = %d\n", max);
	
}


int main(){
	int n;
	
	do{
		printf("Enter n: ");
		scanf("%d", &n);
	
		if(n < 0){
			printf("n must be non-negative integer. Try again.\n");
		}
	}
	while(n < 0);
	
	minMax(n);
	
	return 0;
}
