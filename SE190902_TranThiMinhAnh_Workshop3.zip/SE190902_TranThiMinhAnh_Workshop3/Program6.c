#include <stdio.h>
#include <math.h>

int isFibo(int n){
    int t1 = 1, t2 = 1, f = 1;
    
    if(n == 1){
    	return 1;
	}
	
	while(f < n){
		f = t1 + t2;
    	t1 = t2;
    	t2 = f;
	}
	
	if(n == f){
		return 1;
	}
} 

int main(){
	int n, f;
	
	do{
		printf("Enter n: ");
		scanf("%d", &n);
		if(n < 1){
			printf("n >= 1");
		}
	}
	while(n < 1);
	
	if(isFibo(n) == 1){
		printf("It is a Fibonacci element.");
	}
	else{
		printf("It is not a Fibonacci element.");
	}
		
	return 0;
}

