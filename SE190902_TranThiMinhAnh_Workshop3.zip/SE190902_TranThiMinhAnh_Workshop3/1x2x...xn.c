#include <stdio.h>
#include <math.h>

double factorial (int n){
    double p=1;
    
    for(int i = 2; i <=n ; i++){
    	p *= i;
	}
	
    return p;
} 

int main(){
	int n;
	double p;
	
	do{
		printf("Enter n: ");
		scanf("%d", &n);
		if(n < 0){
			printf("n must be non-negative");
		}
	}
	while(n < 0);
	
	p = factorial(n);
	printf("P = %.2lf", p);
	
	return 0;
}

