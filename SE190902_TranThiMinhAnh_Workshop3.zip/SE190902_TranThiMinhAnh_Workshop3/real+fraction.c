#include <stdio.h>
#include <math.h>

double realNum(int n, int m){
	double val, fraction = m;
	
	while(fraction > 1){
		fraction = fraction / 10;
	}
	
	if(n < 0){
		val = n - fraction;
	}
	else{
		val = n + fraction;
	}
	
	return val;
}


int main(){
	int n;
	int m;
	double value;
	
	printf("Enter integral part: ");
	scanf("%d", &n);
	
	do{
		printf("Enter fraction: ");
		scanf("%d", &m);
	
		if(m < 0){
			printf("Fraction must be non-negative. Try again.\n");
		}
	}
	while(m < 0);
	
	value = realNum(n, m);
	
	printf("Real number: %lf\n", value);
	
	return 0;
}
