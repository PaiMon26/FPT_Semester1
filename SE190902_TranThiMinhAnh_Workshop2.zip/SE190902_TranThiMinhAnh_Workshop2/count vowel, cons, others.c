#include <stdio.h>
#include <ctype.h>

void character(int *nVowels, int *nConsonants, int *nOthers){
	char ch;
	
	printf("Enter a string of characters: ");
	
	do{
		ch = getchar();
		ch = toupper(ch);
		
		if(ch >= 'A' && ch <= 'Z'){
			switch(ch){
			case 'A':
			case 'U':
			case 'E':
			case 'O':
			case 'I':
				(*nVowels)++;
				break;
			default: 
				(*nConsonants)++;
			}
		}
		else if(ch != '\n'){
			(*nOthers)++;
		}
		
	}
	while(ch != '\n');
}

int main(){
	int nVowels = 0, nConsonants = 0, nOthers = 0;
	character(&nVowels, &nConsonants, &nOthers);
	
	printf("Number of vowels: %d\n", nVowels);
	printf("Number of consonants: %d\n", nConsonants);
	printf("Number of others: %d\n", nOthers);
	
	return 0;
}
