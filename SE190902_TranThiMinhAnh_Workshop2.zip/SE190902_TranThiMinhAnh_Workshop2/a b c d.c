#include <stdio.h>

int different(int c1, int c2){
	int d;
	char t;
	
	if(c1 > c2){
		t = c1;
		c1 = c2;
		c2 = t;
	}
	
	d = c2 - c1;
	
	return d;
}

void character(char c1, char c2){
	char t;
	if(c1 > c2){
		t = c1;
		c1 = c2;
		c2 = t;
	}
	
	for(char c = c1; c <= c2; c++){
		printf("%c : %d, %o, %X\n", c, c, c, c);
	}
}

int main(){
	char c1, c2;
	int d;
	
	printf("Enter c1: ");
	scanf(" %c", &c1);
	printf("Enter c2: ");
	scanf(" %c", &c2);
	
	d = different(c1, c2);
	printf("d = %d\n", d);
	character(c1, c2);
	
	return 0;
}
