#include <stdio.h>
#include <math.h>

int isPrime(int n) {
    if (n <= 1) return 0;
    for (int i = 2; i <= sqrt(n); i++) {
        if (n % i == 0) return 0;
    }
    return 1;
}

void min_max_digits(int n, int *min, int *max) {
    *min = 9;
    *max = 0;
    while (n > 0) {
        int digit = n % 10;
        if (digit < *min) *min = digit;
        if (digit > *max) *max = digit;
        n /= 10;
    }
}

int main() {
    int choice;
    int n;
    do {
        printf("1- Process primes\n");
        printf("2- Print min, max digit in an integer\n");
        printf("3- Quit\n");
        printf("Select an operation: ");
        scanf("%d", &choice);
        
        switch(choice){
        	case 1:
        		do{
        			printf("Enter a positive integral number: ");
            		scanf("%d", &n);
            		if(n < 0){
            			printf("Invalid value. Enter again.\n");
					}
				}
        		while(n < 0);
        		
            	if (isPrime(n)){
                	printf("%d is a prime number.\n", n);
            	} 
				else {
                printf("%d is not a prime number.\n", n);
            	}
            	printf("\n");
            	break;
            case 2:
          		do{
        			printf("Enter a positive integral number: ");
            		scanf("%d", &n);
            		if(n < 0){
            			printf("Invalid value. Enter again.\n");
					}
				}
        		while(n < 0);
            	int min, max;
            	min_max_digits(n, &min, &max);
            	printf("Minimum digit: %d, Maximum digit: %d\n", min, max);
        		printf("\n");
				break;
        	case 3:
        		printf("Quitting the program. Goodbye!\n");
        		printf("\n");
				break;
        	default:
        		printf("Invalid choice. Please select again.\n");
        		printf("\n");
				break;
		}

    } while (choice != 3);

    return 0;
}

