#include <stdio.h>
#include <math.h>

int gcd(int a, int b){
	while(a != b){
		if(a > b){
			a -= b;
		}
		else{
			b -= a;
		}
	}
	return a;
}

int lcm(int a, int b){
	return a * b / gcd(a, b);
}


int main(){
	int a, b;
	int d, m;
	
	do{
		printf("Enter a: ");
		scanf("%d", &a);
		printf("Enter b: ");
		scanf("%d", &b);
	
		if(a <= 0 || b <= 0){
			printf("a and b are positive integers. Try again.\n");
		}
	}
	while(a <= 0 || b <= 0);
	
	d = gcd(a, b);
	m = lcm(a, b);
	
	printf("Greatest common divisor: %d\n", d);
	printf("Least common multiple: %d\n", m);
	
	return 0;
}
