#include <stdio.h>

int main(){
	int n, m;   
	scanf("%d,%d",&n, &m);   
	printf("%d, %d", n, m);   
	getch();   
	return 1;
}
