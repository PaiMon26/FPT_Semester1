#include <stdio.h>
#include <math.h>

int checkPrime(int n){
	for(int i = 2; i <= sqrt(n); i++){
		if(n % i == 0){
			return 0;
		}
	}
	return 1;
}

void printPrime(int n){
	for(int i = 2; i <= n; i++){
		if(checkPrime(i)){
			printf("%d ", i);
		}
	}
}

int main(){
	int n;
	
	do{
		printf("Enter n: ");
		scanf("%d", &n);
	
		if(n < 2){
			printf("Invalid value, enter n >= 2");
		}
	}
	while(n < 2);
	
	printf("Prime numbers between 2 and %d are:\n", n);
	printPrime(n);
	
	return 0;
}
