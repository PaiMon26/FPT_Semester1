#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int intRandom(int min, int max){
	return min + (rand() % (max - min + 1));
}

int main(){
	int total, x, y, count;
	printf(" Ball Lottery\n");
	printf("============\n");
	
	do{
		printf("Total sought: ");
		scanf("%d", &total);
		fflush(stdin);
		if (total < 2 || total > 20){
			printf("Enter again.\n");
		}
	}
	while (total < 2 || total > 20);
	
	count = 0;
	
	do{
		x = intRandom(1, 10);
		y = intRandom(1,10);
		count++;
		printf("Result of picks %d and %d: %d + %d\n", count, count + 1, x, y);
		count++;
	}
	while (total != x + y);
	
	if (total == x + y){
		printf("You got your total in %d picks!\n", count);
	}
	
	getchar();;
	return 0;
}
