#include <stdio.h>
#include <math.h>

void swap(int *x, int *y){
	int temp;

	temp = *x;
	*x = *y;
	*y = temp;

}

int main(){
	int x, y;
	
	do{
		printf("x = ");
		scanf("%d", &x);
		printf("y = ");
		scanf("%d", &y);
		if(x != 0 && y != 0){
			swap(&x, &y);
			printf("After swap: x = %d y = %d\n", x, y);
		}
	}
	while(x != 0 && y != 0);
	
	return 0;
}
