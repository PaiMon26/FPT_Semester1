#include <stdio.h>
#include <math.h>

int sum(){
	int x;
	int s = 0;
	
	printf("Enter x (0 to stop):\n");
	do{
		scanf("%d", &x);
		
		if(x != 0){
			s += x;
		}
	}
	while(x != 0);
	
	return s;
}

int main(){
	int s = sum();
	printf("sum = %d", s);
	
	return 0;
}
