#include <stdio.h>
#include <math.h>

void quadratic(double a, double b, double c) {
    double x1, x2, delta;
    if (a == 0 && b == 0 && c == 0) {
        printf("The equation has infinitely many solutions.\n");
    } else if (a == 0 && b == 0 && c != 0) {
        printf("The equation has no solution.\n");
    } else if (a == 0 && b != 0) {
        x1 = -c / b;
        printf("This is a linear equation: x = %.2lf\n", x1);
    } else if (a != 0) {
        delta = b * b - 4 * a * c;
        if (delta < 0) {
            printf("The equation has no real solution.\n");
        } else if (delta == 0) {
            x1 = -b / (2 * a);
            printf("Roots are real and the same.\n");
            printf("x1 = x2 = %.2lf\n", x1);
        } else if (delta > 0) {
            x1 = (-b + sqrt(delta)) / (2 * a);
            x2 = (-b - sqrt(delta)) / (2 * a);
            printf("Roots are real and different.\n");
            printf("x1 = %.2lf, x2 = %.2lf\n", x1, x2);
        }
    }
}

float bank_deposit(int deposit, float rate, int year) {
    float P;
    P = (float) deposit * pow((1 + rate), year);
    return P;
}

int main() {
    int deposit, year;
    float P, rate;
    double a, b, c;
    int choice;

    printf("1- Quadratic equation\n");
    printf("2- Bank deposit problem\n");
    printf("3- Quit\n");

    do {
        printf("\nChoose your operation: ");
        scanf("%d", &choice);
        fflush(stdin);
        printf("\n");
        switch (choice) {
            case 1:
                printf("Enter a: ");
                scanf("%lf", &a);
                fflush(stdin);
                printf("Enter b: ");
                scanf("%lf", &b);
                fflush(stdin);
                printf("Enter c: ");
                scanf("%lf", &c);
                fflush(stdin);
                quadratic(a, b, c);
                break;
            case 2:
                printf("Enter deposit: ");
                scanf("%d", &deposit);
                fflush(stdin);
                do {
                    printf("Enter rate (> 0 and <= 0.1): ");
                    scanf("%f", &rate);
                    fflush(stdin);
                } while (rate <= 0 || rate > 0.1);
                printf("Enter number of years: ");
                scanf("%d", &year);
                fflush(stdin);
                P = bank_deposit(deposit, rate, year);
                printf("Amount after %d years is: %.2f\n", year, P);
                break;
            case 3:
                printf("Exit the program. Goodbye!\n");
                break;
            default:
                printf("Invalid value. Enter again: ");
        }
    } while (choice != 3);

    return 0;
}

