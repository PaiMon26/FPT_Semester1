#include <stdio.h>
#include <math.h>

int incometax(int ti){
	
	int tax;
	
	if(ti <= 0){
		tax = 0;
	}
	else if(ti <= 5000000){
		tax = ti * 0.05;
	}
	else if(ti <= 10000000){
		tax = 5000000 * 0.05 + (ti - 5000000) * 0.1;
	}
	else if(ti <= 18000000){
		tax = 5000000 * 0.05 + 5000000 * 0.1 + (ti - 10000000) * 0.15;
	}
	else{
		tax = 5000000 * 0.05 + 5000000 * 0.1 + 8000000 * 0.15 + (ti - 18000000) * 0.2;
	}
	
	return tax;
}



int main(){
	int income, n, pa, pd, tf, ti, tax;
	
	pa = 9000000;
	pd = 3600000;
	
	printf("Your income of this year: ");
	scanf("%d", &income);
	printf("Number of dependent: ");
	scanf("%d", &n);
	
		
	tf = 12 * (pa + n * pd);
	ti = income - tf;
	
	if(ti <= 0){
		ti = 0;
	}
	
	tax = incometax(ti);
	printf("Tax-free income: %d\n", tf);
	printf("Taxable income: %d\n", ti);
	printf("Income tax: %d\n", tax);
	
	return 0;
}
