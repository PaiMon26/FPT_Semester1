#include <stdio.h>
#include <stdbool.h>

void printFibonacci(int n) {
    int a = 0, b = 1, next;
    printf("Fibonacci sequence: ");
    int i = 1;
    for (i; i <= n; i++) {
        printf("%d ", a);
        next = a + b;
        a = b;
        b = next;
    }
    printf("\n");
}


int leapYear(int year) {
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
        return 1; 
    } else {
        return 0; 
    }
}


int validDate(int day, int month, int year) {
    if (year < 1 || month < 1 || month > 12 || day < 1) return 0;
    
    switch(month){
    	case 1:
    	case 3:
    	case 5:
    	case 7:
    	case 8:
    	case 10:
    	case 12:
    		return (day <= 31);
    	case 4:
    	case 6:
    	case 9:
    	case 11:
    		return (day <= 30);
    	case 2:
    		if(leapYear(year)){
    			return (day <= 29);
			}
			else return (day <= 28);
		default:
			return 0;
	}
}

int main() {
    int choice;
    int n;
    do {
        printf("1- Fibonacci sequence\n");
        printf("2- Check a date\n");
        printf("3- Quit\n");
        printf("Choose an operation: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: {
                do{
        			printf("Enter a positive integral number: ");
            		scanf("%d", &n);
            		if(n < 0){
            			printf("Invalid value. Enter again.\n");
					}
				}
				while(n < 0);
				printFibonacci(n);
				printf("\n");
                break;
            }
            case 2: {
                int day, month, year;
                printf("Enter a date (day/month/year): ");
                scanf("%d/%d/%d", &day, &month, &year);
                if(validDate(day, month, year)){
                    printf("The date %02d/%02d/%04d is valid.\n", day, month, year);
                } else {
                    printf("The date %02d/%02d/%04d is invalid.\n", day, month, year);
                }
                printf("\n");
                break;
            }
            case 3:
                printf("Quitting the program. Goodbye!\n");
                printf("\n");
                break;
            default:
                printf("Invalid choice. Please select again.\n");
                printf("\n");
        }
    } while (choice != 3);

    return 0;
}

