#include <stdio.h>
#include <math.h>

int findIndex(int arr[], int n, int x){
	for(int i = 0; i < n; i++){
		if(arr[i] == x) return i;
	}
	return -1;
}

void enterArr(int arr[], int n){
	for(int i = 0; i < n; i++){
		printf("Enter the %d element: ", i + 1);
		scanf("%d", &arr[i]);
	}
	
	printf("Array:\n");
	for(int i = 0; i < n; i++){
		printf("%d ", arr[i]);
	}
}

int main(){
	int n;
	
	printf("Enter number of elements: ");
    while (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid input. Array must have at least 1 value. Try again.\n");
        printf("Enter number of elements: ");
        while (getchar() != '\n');
    }
    
    int arr[n];
    enterArr(arr, n);
    
    int x;
    printf("\nEnter the integer number to search for: ");
    scanf("%d", &x);
    
    int i = findIndex(arr, n, x);
    
    if(i != -1){
    	printf("\nThe first index of %d in the array is: %d\n", x, i);
	}
	else{
		printf("-1");
	}
    
	return 0;
}
