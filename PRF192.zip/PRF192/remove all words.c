#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define MAX_SIZE 100 // Maximum string size

/* Function declaration */
void removeAll(char *str, const char *toRemove);

int main()
{
    char str[MAX_SIZE];
    char toRemove[MAX_SIZE];

    /* Input string and word from user */
    printf("Enter any string: ");
    fgets(str, MAX_SIZE, stdin);
    str[strcspn(str, "\n")] = 0; // Remove the newline character at the end of the string
    printf("Enter word to remove: ");
    fgets(toRemove, MAX_SIZE, stdin);
    toRemove[strcspn(toRemove, "\n")] = 0; // Remove the newline character at the end of the string

    printf("String before removing '%s':\n%s\n", toRemove, str);

    removeAll(str, toRemove);

    printf("\nString after removing '%s':\n%s\n", toRemove, str);

    return 0;
}

/**
 * Remove all occurrences of a given word in string.
 */
void removeAll(char *str, const char *toRemove)
{
    int i, j, stringLen, toRemoveLen;
    int found;

    stringLen = strlen(str);       // Length of string
    toRemoveLen = strlen(toRemove); // Length of word to remove

    for (i = 0; i <= stringLen - toRemoveLen;)
    {
        /* Match word with string */
        found = 1;
        for (j = 0; j < toRemoveLen; j++)
        {
            if (str[i + j] != toRemove[j])
            {
                found = 0;
                break;
            }
        }

        /* If it is not a word */
        if (found == 1 && (i == 0 || isspace(str[i - 1])) && (isspace(str[i + toRemoveLen]) || str[i + toRemoveLen] == '\0'))
        {
            /* Shift all characters to the left */
            for (j = i; j <= stringLen - toRemoveLen; j++)
            {
                str[j] = str[j + toRemoveLen];
            }

            stringLen = stringLen - toRemoveLen;
            str[stringLen] = '\0'; // Null-terminate the string

            // We will match next occurrence of word from current index.
        }
        else
        {
            i++;
        }
    }
}

