#include <stdio.h>
#include <string.h>
#include <ctype.h>

void concatenate(char *c1, char *c2){
	char c3[200];
	strcpy(c3, c1);
	strcat(c3, " ");
	strcat(c3, c2);
	
	printf("After concatenate: %s", c3);
}

int main(){
	char c1[100], c2[100];
	char c3[200];
	
	printf("Enter first string: ");
	fgets(c1, sizeof(c1), stdin);
	c1[strcspn(c1, "\n")] = '\0';
	printf("Enter second string: ");
	fgets(c2, sizeof(c2), stdin);
	c2[strcspn(c2, "\n")] = '\0';
	
	concatenate(c1, c2);
	getchar();
	return 0;
}
