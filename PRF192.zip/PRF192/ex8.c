#include <stdio.h>
#include <math.h>

int main(){
	
	float a, b, perimeter, area;
	
	printf("Enter length: ");
	scanf("%f", &a);
	printf("Enter width: ");
	scanf("%f", &b);
	
	perimeter = (a + b) * 2;
	area = a * b;
	
	printf("The perimeter is: %.1f", perimeter);
	printf("\nThe area is: %.1f", area);
	
	return 0;
}
