#include <stdio.h>
#include <math.h>

int main(){
	
	int n, i, S;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	i = 1;
	S = 0;
	
	if(n < 0){
		printf("Invalid value, n >= 0\n");
	}
	else{
		while(i <= n){
			S = S + i;
			i = i + 2;
		}
		printf("S = %d", S);
	}
	
	return 0;
}
