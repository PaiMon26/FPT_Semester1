#include <stdio.h>

void main()
{
	printf("xin chao");
}
