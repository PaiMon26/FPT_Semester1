#include <stdio.h>
#include <math.h>

void divisors(int n){

	for(int i = 1; i < n; i++){
		if(n % i == 0){
			printf("%d ", i);
		}
	}
}


int main(){
	
	int n;
	
	printf("Enter n: ");
	scanf("%d", &n);
		
	if(n <= 0){
		printf("Invalid value, n is a positive interger.\n");
		return 0;
	}
	
	printf("Divisors of n: ");
	divisors(n);
	
	return 0;
}
