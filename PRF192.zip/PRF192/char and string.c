#include<stdio.h>

int main (){
	char c1 ='A';
	char c2 = 65;
	char c3 = 0101;
	char c4 = 0x41;
	printf("%c %c %c %c",c1,c2,c3,c4);
	return 0;
}

