#include <stdio.h>

int main(){
	
	float a, b, x;
	
	printf("Enter a, b: ");
	scanf("%f%f", &a, &b);
	
	x = (0 - b)/a;
	
	printf("%.2fx + %.2f = 0\n", a, b);
	printf("x = %.2f", x);
	
	return 0;
}
