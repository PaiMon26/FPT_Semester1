/*
#include <stdio.h>

int main(){
	
	int n = 7, m=6;
	int *pn = &n;
	int *pm = &m;
	
	printf("pm=%d, pn=%d\n", *pm, *pn);
	
	*pn = 2*(*pm) + m*n;
	*pm += 3*m - (*pn); 
	
	printf("m=%d, n=%d\n", m, n);

	getchar();
	
	return 0;
}
*/

/*
#include <stdio.h>

int main(){
	
	int n = 7, m=6;
	int *pn = &n;
	int *pm = &m;
	
	printf("pm=%d, pn=%d\n", *pm, *pn);
	
	*pn = *pm + 2*m - 3*n;
	*pm -= *pn; 
	
	printf("%d\n", m + n);

	getchar();
	
	return 0;
}
*/

/*
#include <stdio.h>

int main(){
	
	char c1 = 'A', c2 = 'F';
	char *p1 = &c1;
	char *p2 = &c2;
	
	printf("p1=%d, p2=%d\n", *p1, *p2);
	
	*p1 += 3;
	*p2 -= 5; 
	
	printf("%d\n", c1 - c2);

	getchar();
	
	return 0;
}
*/

/* file pointer_demo4.c */
#include <stdio.h>
int main()
{  int n2= 10;
   int n1= 6;
   int n0= 5;
   printf("n2=%d, n1=%d, n0=%d\n", n2, n1, n0);
   int *p = &n1;
   *p=9;
   p++;
   *p=15;
   p--;
   p--;
   *p=-3;
   printf("n2=%d, n1=%d, n0=%d\n", n2, n1, n0);
   getchar();
   return 0;
}
