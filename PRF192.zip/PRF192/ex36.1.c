#include <stdio.h>
#include <math.h>

int main(){
	
	int n;
	float S, i;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	i = 1;
	S = 0;
	
	if(n <= 0){
		printf("Invalid value, n > 0\n");
	}
	else{
		for(i; i <= n; i++){
			S = S + 1/i;
		}
		printf("S = %.3f", S);
	}
	
	return 0;
}
