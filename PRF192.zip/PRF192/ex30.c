#include <stdio.h>

int main(){
	
	float a, b;
	char op;
	
	printf("Enter an expression (ex: 2.3 + 1): ");
	scanf("%f %c %f", &a, &op, &b);
	
	switch (op){
		case '+':
			printf("= %.2f", a + b);
			break;
		case '-':
			printf("= %.2f", a - b);
			break;
		case '*':
			printf("= %.2f", a * b);
			break;
		case '/':
			printf("= %.2f", a / b);
			break;
		default:
			printf("Operation is not supported!");
		
	}
	
	return 0;
}
