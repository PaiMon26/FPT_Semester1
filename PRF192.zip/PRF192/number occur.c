#include <stdio.h>
#include <ctype.h>
#include <string.h>

int occurrence(char str[], char ch){
	int count = 0;
	for (int i = 0; i < strlen(str); i++){
		if (str[i] == ch){
			count++;
		}
	}
	return count;
}

int main(){
	char str[100];
	char ch;
	int count;
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	printf("Enter a character to find: ");
	scanf("%c", &ch);
	
	count = occurrence(str, ch);
	
	if (count != 0){
		printf("The character %c occur %d times.\n", ch, count);
	}
	else{
		printf("The character %c is not found in the string.\n", ch);
	}
	
	return 0;
}
