#include <stdio.h>
#include <math.h>

int main(){
	
	int n, i, count;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	i = 1;
	count = 0;
	
	if(n <= 0){
		printf("Invalid value, n > 0\n");
	}
	else{
		while(i <= n){
			if(n % i == 0){
				count = count + 1;
			}
			i = i + 1;
		}
		printf("Number of divisors of %d is %d", n, count);
	}
	
	return 0;
}
