#include <stdio.h>
#include <math.h>

int main(){
	
	int n, i, P;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	i = 1;
	P = 1;
	
	if(n < 0){
		printf("Invalid value, n >= 0\n");
	}
	else{
		while(i <= n){
			P = P * i;
			i = i + 2;
		}
		printf("P = %d", P);
	}
	
	return 0;
}
