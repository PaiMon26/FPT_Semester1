#include <stdio.h>
#include <string.h>
#include <ctype.h>

char* lTrim(char s[]){
    int i = 0;
    while (s[i] == ' ') i++;
    if (i > 0) strcpy(s, &s[i]);
    return s;
}

char* rTrim(char s[]){
    int i = strlen(s) - 1;
    while (i >= 0 && s[i] == ' ') i--;
    s[i + 1] = '\0';
    return s;
}

char* trim(char s[]){
    rTrim(lTrim(s)); 
    char *ptr = strstr(s, "  ");
    while (ptr != NULL){
        strcpy(ptr, ptr + 1);
        ptr = strstr(s, "  ");
    }
    return s;
}


char* strlwr_custom(char s[]){
    for (int i = 0; s[i]; i++){
        s[i] = tolower((unsigned char)s[i]);
    }
    return s;
}

char* nameStr(char s[]){
    trim(s);
    strlwr_custom(s);
    int L = strlen(s);
    for (int i = 0; i < L; i++){
        if (i == 0 || (i > 0 && s[i - 1] == ' ')) s[i] = toupper(s[i]);
    }
    return s;
}

int main(){
    char s[50]; // Increased size for longer input
    printf("Enter string s1: ");
    scanf(" %[^\n]s", s); // Safe input with fgets
    
    s[strcspn(s, "\n")] = '\0'; // Remove newline character if present
    
    trim(s);
    printf("After removing extra blanks: ");
    puts(s);
    
    nameStr(s);
    printf("After converting to a name: ");
    puts(s);
    
    getchar(); // Wait for a character input before exiting
    return 0;
}

