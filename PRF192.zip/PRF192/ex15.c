#include <stdio.h>

int main(){
	
	float cm, m, km;
	
	printf("Enter length in centimeter: ");
	scanf("%f", &cm);
	
	m = cm/100;
	km = cm/100000;
	
	printf("\n%.2f cm = %f m", cm, m);
	printf("\n%.2f cm = %f km", cm, km);
	
	return 0;
}
