#include <stdio.h>
#include <math.h>

int main(){
	
	int n, i, m, S;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	i = 0;
	S = 0;
	m = 0;
	
	if(n <= 0){
		printf("Invalid value, n > 0\n");
	}
	else{
		for(i; i <= n; ++i){
			m = pow(-1, (i + 1)) * i;
			S = S + m;
		}
		printf("S = %d", S);
	}
	
	return 0;
}
