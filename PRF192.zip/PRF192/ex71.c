#include <stdio.h>
#include <math.h>

int countOdd(int arr[], int n){
	int count = 0;	
	for(int i = 0; i < n; i++){
		if(arr[i] % 2 != 0){
			count += 1;
		}
	}
	return count;
}

void enterArr(int arr[], int n){
	for(int i = 0; i < n; i++){
		printf("Enter the %d element: ", i + 1);
		scanf("%d", &arr[i]);
	}
	
	printf("Array:\n");
	for(int i = 0; i < n; i++){
		printf("%d ", arr[i]);
	}
}

int main(){
	int n;
	
	printf("Enter number of elements: ");
    while (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid input. Array must have at least 1 value. Try again.\n");
        printf("Enter number of elements: ");
        while (getchar() != '\n');
    }
    
    int arr[n];
    enterArr(arr, n);
    int count = countOdd(arr, n);
    printf("\nThere are %d odd numbers.", count);
    
	return 0;
}
