#include <stdio.h>

int main(){
	
	float n1, n2, quotient;
	
	printf("Enter first float number: ");
	scanf("%f", &n1);
	printf("Enter second float number: ");
	scanf("%f", &n2);
	
	quotient = n1 / n2;
	
	printf("The quotient is: %.2lf", quotient);
	
	return 0;
}
