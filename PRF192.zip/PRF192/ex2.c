#include<stdio.h>

int main(){
	
	printf("Student name: Tran Thi Minh Anh\n");
	printf("Student ID: SE190902\n");
	printf("Class ID: IA1902\n");
	printf("Date of birt: 26/10/2005\n");
	printf("Mobile number: 0865952305\n");
	
	return 0;
}
