#include <stdio.h>
#include <ctype.h>
#include <string.h>

int first_occurrence(char str[], char ch){
	for (int i = 0; i < strlen(str); i++){
		if (str[i] == ch){
			return i;
		}
	}
	return -1;
}

int main(){
	char str[100];
	char ch;
	int position;
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	printf("Enter a character to find: ");
	scanf("%c", &ch);
	
	position = first_occurrence(str, ch);
	
	if (position != -1){
		printf("The first occurrence of %c is at index %d\n", ch, position);
	}
	else{
		printf("The character %c is not found in the string.\n", ch);
	}
	
	return 0;
}
