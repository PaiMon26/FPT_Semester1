#include <stdio.h>

void array(int arr[], int n){
	printf("Enter elements:\n");
	
	for(int i = 0; i < n; i++){
		do{
			scanf("%d", &arr[i]);
			if(arr[i] < 2){
				printf("arr[i] >= 2, try again\n");
			}
		}	
		while(arr[i] < 2);
	}
	
	for(int i = 0; i < n; i++){
		printf("%d ", arr[i]);
	}
}

int checkPrime(int arr[], int n){
	for(int i = 2; i < arr[n]; i++){
		if(arr[n] % i == 0){
			return 0;
		}
	}
	return 1;
}

void printPrime(int arr[], int n){
	for(int i = 0; i < n; i++){
		if(checkPrime(arr, i)){
			printf("%d ", arr[i]);
		}
	}
}


int main(){
	int n;
	
	printf("Enter number of elements: ");
	scanf("%d", &n);
	
	int arr[n];
	
	array(arr, n);
	printf("\nPrime numbers in array:\n");
	printPrime(arr, n);
	
	return 0;
}
