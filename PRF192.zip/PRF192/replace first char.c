#include <stdio.h>
#include <ctype.h>
#include <string.h>

void replace(char str[], char n, char m){
	for (int i = 0; i < strlen(str); i++){
		if (str[i] == n){
			str[i] = m;
			break;
		}
	}
}

int main(){
	char str[100];
	char n, m;
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	printf("Enter the character to replace: ");
	scanf("%c", &n);
	getchar();
	printf("Enter the new character: ");
	scanf("%c", &m);
	getchar();
	
	replace(str, n, m);
	printf("Modified string: %s", str);
		
	return 0;
}
