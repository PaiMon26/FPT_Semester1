#include <stdio.h>
#include <math.h>

void checkPrime(int n){

	for(int i = 2; i <= sqrt(n); i++){
		if(n % i == 0){
			printf("%d is not a prime number.\n", n);
			return;
		}
	}
	printf("%d is a prime number.\n", n);
}


int main(){
	
	int n;
	
	printf("Enter n (n >= 2): ");
	scanf("%d", &n);
		
	if(n < 2){
		printf("Invalid value.\n");
		return 0;
	}

	checkPrime(n);
	
	return 0;
}
