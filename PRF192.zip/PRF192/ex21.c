#include <stdio.h>

int main(){
	
	int a, b, c, i;
	
	printf("Enter a: ");
	scanf("%d", &a);
	printf("Enter b: ");
	scanf("%d", &b);
	printf("Enter c: ");
	scanf("%d", &c);
	
	if(a>b){
		i = a;
		a = b;
		b = i;
	}
	if(a>c){
		i = a;
		a = c;
		c = i;
	}
	if(b>c){
		i = b;
		b = c;
		c = i;
	}
	printf("%d, %d, %d", a, b, c);
	
	return 0;
}
