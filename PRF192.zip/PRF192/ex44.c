#include <stdio.h>
#include <math.h>

int UCLN(int a, int b){

	while(a != b){
		if(a > b){
			a -= b;
		}
		else{
			b -= a;
		}
	}
	return a;
}

int BCNN(int a, int b){
	
	int bcnn = a * b / UCLN(a, b);
	
	return bcnn;
}
	
	
int main(){
	
	int a, b;
	
	printf("Enter a: ");
	scanf("%d", &a);
	printf("Enter b: ");
	scanf("%d", &b);
	
	printf("UCLN = %d\n", UCLN(a,b));
	printf("BCNN = %d\n", BCNN(a,b));
	
	return 0;
}
