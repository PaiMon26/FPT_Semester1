
#include<stdio.h>
#include<math.h>

int main(){
    float a, b, c, x1, x2, delta;
	printf("Enter a, b, c: ");
	scanf("%f %f %f", &a, &b, &c);
	if (a == 0){
		if (b == 0){
			if (c == 0){
				printf("The equation has infinitely many solutions.\n");
			}
			else{
				printf("The equation has no solution.\n");
			}
		}
		else{
			x1 = -c / b;
			printf("The quation is linear x = %.2f\n", x1 );
		}	
	}
	else {
		delta = b * b - 4 * a * c;
		if (delta > 0){
			x1 = (-b + sqrt(delta)) / (2 * a);
			x2 = (-b - sqrt(delta)) / (2 * a);
			printf("The equation has 2 distinct solutions:\nx1 = %.2f\t x2 = %.2f", x1, x2);			
		}
    	else if (delta == 0){
       		x1 = -b / (2 * a);
       		printf("The quation has 1 double solution x = %.2f\n", x1);
    	}
    	else if (delta < 0 ){
			printf("The equation has no solution.\n");
		}
	}
	
    return 0;
}
