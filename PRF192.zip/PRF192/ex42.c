#include <stdio.h>
#include <math.h>

int isPrime(int n){

	for(int i = 2; i <= sqrt(n); i++){
		if(n % i == 0){
			return 0;
		}
	}
	return 1;
}


int main(){
	
	int n, sum = 0;
	
	printf("Enter n (n >= 2): ");
	scanf("%d", &n);
		
	if(n < 2){
		printf("Invalid value.\n");
		return 0;
	}

	for(int i = 2; i < n; i++){
		if(isPrime(i)){
		sum += i;
		}
	}
	
	
	printf("Sum of prime numbers less than %d = %d", n, sum);
	
	return 0;
}
