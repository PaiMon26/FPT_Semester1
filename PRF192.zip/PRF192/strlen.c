#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(){
	char string[31];
	printf("Enter a string: ");
	scanf("%[^\n]", string);
	int l = strlen(string);
	printf("The length of the string is: %d", l);
	getchar();
	return 0;
}

