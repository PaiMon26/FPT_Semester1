#include <stdio.h>

int main(){
	
	int a, b, c, max;
	
	printf("Enter a: ");
	scanf("%d", &a);
	printf("Enter b: ");
	scanf("%d", &b);
	printf("Enter c: ");
	scanf("%d", &c);
	
	if(a>b){
		max = a;
	}
	else {
		max = b;
	}
	if(max>c){
		printf("The largest number is %d\n", max);
	}
	else{
		printf("The largest number is: %d\n",c);
	}
	
	return 0;
}
