#include <stdio.h>
#include <math.h>

int main(){
	
	int n, m, S, i;
	S = 0;
	i = 1;
	m = 1;
	//p
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	if (n <= 0){
		printf("Invalid value, n > 0");
	}
	else{
		for(i; i <= n; i++){
			m *= i;
			S = S + m;
		}
	printf("S = %d", S);
	}
	
	return 0;
}
