#include <stdio.h>

int main(){
	
	int n, a, b, c, temp;
	
	printf("Enter a three-digit number: ");
	scanf("%d", &n);
	
	a = n%10;
	b = (n - a) / 10 % 10;
	c = (n - a - b * 10) / 100;
	
	if (a > b){
		temp = a;
		a = b;
		b = temp;
	}
	if (a > c){
		temp = a;
		a = c;
		c = temp;
	}
	if (b > c){
		temp = b;
		b = c;
		c = temp;
	}
	
	printf("%d%d%d\n", a, b, c);
	
	return 0;
}
