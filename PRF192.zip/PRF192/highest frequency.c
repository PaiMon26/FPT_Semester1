#include <stdio.h>
#include <string.h>
#include <ctype.h>

int highest_freq(char str[]){
	int count[256] = {0};
	int max_freq = -1;
	char max_char = '\0';
	
	for (int i = 0; str[i] != '\0'; i++){
		count[str[i]]++;
	}
	
	for (int i = 0; i < 256; i++){
		if (count[i] > max_freq){
			max_freq = count[i];
			max_char = (char)i;
		}
	}
	
	return max_char;
}


int main(){
	char str[100];
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	char max_char = highest_freq(str);
	printf("The highest frequency character is '%c'.\n", max_char);
	
	return 0;
}
