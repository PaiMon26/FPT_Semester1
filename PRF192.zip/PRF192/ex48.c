#include <stdio.h>
#include <math.h>

int perfectCheck(int n){
	
	int s = 1;
	
	for(int i = 2; i < sqrt(n); i++){
		if(n % i == 0){
			if(i == (n / i)){
				s += i;
			}
			else{
				s += i + (n / i);
			}
		}
	}
	
	return s;
}


void allPerfect(int n){
	
	for (int i = 2; i < n; i++) {
        if (i == perfectCheck(i)) {
            printf("%d ", i);
        }
    }
}


int main(){
	
	int n;
	
	printf("Enter a number: ");
	scanf("%d", &n);
	
	printf("All perfect numbers less than %d: ", n);
	allPerfect(n);

	return 0;
}
