#include <stdio.h>
#include <math.h>

int lastOdd(int arr[], int n){	
	for(int i = n - 1; i >= 0; i--){
		if(arr[i] % 2 != 0){
			return arr[i];
		}
	}
	return arr[n-1];
}

void enterArr(int arr[], int n){
	for(int i = 0; i < n; i++){
		printf("Enter the %d element: ", i + 1);
		scanf("%d", &arr[i]);
	}
	
	printf("Array:\n");
	for(int i = 0; i < n; i++){
		printf("%d ", arr[i]);
	}
}

int main(){
	int n;
	
	printf("Enter number of elements: ");
    while (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid input. Array must have at least 1 value. Try again.\n");
        printf("Enter number of elements: ");
        while (getchar() != '\n');
    }
    
    int arr[n];
    enterArr(arr, n);
    int odd = lastOdd(arr, n);
    if(odd % 2 == 0){
    	printf("\nThe last number is: %d", odd);
	}
	else{
		printf("\nThe last odd is: %d", odd);
	}
    
	return 0;
}
