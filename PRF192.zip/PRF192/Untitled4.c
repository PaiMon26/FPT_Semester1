#include <stdio.h>

int main(int argc, char * argv[]) {
    printf("Number of command line arguments: %d\n", argc);
    printf("Program name: %s\n", argv[0]);

    for (int i = 1; i < argc; i++) {
        printf("Argument %d: %s\n", i, argv[i]);
    }
    
    return 0; // Chuong tr�nh d� th?c thi th�nh c�ng
}







