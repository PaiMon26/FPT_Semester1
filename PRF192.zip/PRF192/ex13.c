#include <stdio.h>

int main(){
	
	int m, h;
	
	printf("Enter minutes: ");
	scanf("%d", &m);
	
	h = m / 60;
	m = m % 60;
	
	printf("It is %d h %d m", h, m);
	
	return 0;
}
