#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isWord(char ch){
	return isalpha(ch);
}

int countW(char str[]){
	int count = 0;
	int inWord = 0;
	
	for (int i = 0; i < strlen(str); i++){
		if (isWord(str[i])){
			if (!inWord){
				count ++;
				inWord = 1;
			}
		}
		else {
			inWord = 0;
		}
	}
	return count;
}

int main(){
	char str[100];
	int count;
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	count = countW(str);
	printf("Number of words: %d", count);
	
	return 0;
}
