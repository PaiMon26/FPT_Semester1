#include <stdio.h>
#include <math.h>

int sumArr(int arr[], int n){
	int sum = 0;
	
	for(int i = 0; i < n; i++){
		sum += arr[i];
	}
	
	return sum;
}

int main(){
	int n, sum;
	
	do{
		printf("Enter number of elements: ");
		scanf("%d", &n);
		
		if(n <= 0){
			printf("Array must have at least 1 value. Try again.\n");
		}
	}
	while(n <= 0);
	
	int arr[n];
	
	for(int i = 0; i < n; i++){
		printf("Enter the %d number: ", i + 1);
		scanf("%d", &arr[i]);
	}
	
	sum = sumArr(arr, n);
	
	printf("Sum = %d", sum);
	
	return 0;
}
