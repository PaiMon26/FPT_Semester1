#include <stdio.h>
#include <math.h>

int SumDivisor(int n){
	
	int sum = 0;
	
	for(int i = 1; i < n; i++){
		if(n % i == 0){
			sum += i;
		}
	}
	
	return sum;
}


int main(){
	
	int n, sum;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	sum = SumDivisor(n);
	
	printf("Sum of divisors = %d", sum);
	
	return 0;
}
