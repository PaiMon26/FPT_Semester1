#include <stdio.h>
#include <math.h>

int main(){
	
	const double PI = 3.14;
	double radius, diameter, circumference, area;
	
	printf("Enter radius of a circle: ");
	scanf("%lf", &radius);
	
	diameter = radius * 2;
	circumference = PI * diameter;
	area = PI * radius * radius;
	
	printf("\nThe diameter is: %.1lf", diameter);
	printf("\nThe circumference is: %.1lf", circumference);
	printf("\nThe area is: %.1lf", area);
	
	return 0;
}
