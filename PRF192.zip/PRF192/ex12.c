#include <stdio.h>

int main(){
	
	int a, b, c, d;
	
	printf("Enter hours: ");
	scanf("%d", &a);
	printf("Enter minutes: ");
	scanf("%d", &b);
	printf("Enter seconds: ");
	scanf("%d", &c);
	
	d = a * 60 * 60 + b * 60 + c;
	
	printf("It is %d seconds", d);
	
	return 0;
}
