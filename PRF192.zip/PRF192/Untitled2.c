#include <stdio.h>
#include <math.h>

void calculate_triangle() {
    double a, b, c;
    printf("Enter the length of the first side of the triangle: ");
    scanf("%lf", &a);
    printf("Enter the length of the second side of the triangle: ");
    scanf("%lf", &b);
    printf("Enter the length of the third side of the triangle: ");
    scanf("%lf", &c);

    // Calculate the perimeter
    double perimeter = a + b + c;

    // Calculate the area using Heron's formula
    double s = perimeter / 2;  // semi-perimeter
    double area = sqrt(s * (s - a) * (s - b) * (s - c));

    printf("The perimeter of the Triangle is: %.2lf\n", perimeter);
    printf("The area of the Triangle is: %.2lf\n", area);
}

void calculate_square() {
    double side;
    printf("Enter the length of the side of the square: ");
    scanf("%lf", &side);

    // Calculate the perimeter
    double perimeter = 4 * side;

    // Calculate the area
    double area = side * side;

    printf("The perimeter of the Square is: %.2lf\n", perimeter);
    printf("The area of the Square is: %.2lf\n", area);
}

void calculate_rectangle() {
    double length, width;
    printf("Enter the length of the rectangle: ");
    scanf("%lf", &length);
    printf("Enter the width of the rectangle: ");
    scanf("%lf", &width);

    // Calculate the perimeter
    double perimeter = 2 * (length + width);

    // Calculate the area
    double area = length * width;

    printf("The perimeter of the Rectangle is: %.2lf\n", perimeter);
    printf("The area of the Rectangle is: %.2lf\n", area);
}

void calculate_circle() {
    double radius;
    printf("Enter the radius of the circle: ");
    scanf("%lf", &radius);

    // Calculate the perimeter (circumference)
    double perimeter = 2 * M_PI * radius;

    // Calculate the area
    double area = M_PI * radius * radius;

    printf("The perimeter of the Circle is: %.2lf\n", perimeter);
    printf("The area of the Circle is: %.2lf\n", area);
}

int main() {
    int choice;

    while (1) {
        printf("\nChoose the shape to calculate perimeter and area:\n");
        printf("1. Triangle\n");
        printf("2. Square\n");
        printf("3. Rectangle\n");
        printf("4. Circle\n");
        printf("5. Exit\n");

        printf("Enter your choice (1-5): ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                calculate_triangle();
                break;
            case 2:
                calculate_square();
                break;
            case 3:
                calculate_rectangle();
                break;
            case 4:
                calculate_circle();
                break;
            case 5:
                printf("Exiting the program. Goodbye!\n");
                return 0;
            default:
                printf("Invalid choice. Please choose a valid option.\n");
        }
    }

    return 0;
}



