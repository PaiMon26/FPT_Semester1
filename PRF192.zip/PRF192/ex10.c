#include <stdio.h>

int main() {
    int n;
    
    printf("Enter a positive integer with 2 digits: ");
    scanf("%d", &n);
    
    if (n < 10 || n > 99) {
        printf("Invalid input! Please enter a positive integer with 2 digits.\n");
        return 1;
    }
    
    int digit_sum = (n / 10) + (n % 10);
    printf("Sum of the digits: %d\n", digit_sum);
    
    return 0; 
}

