#include<stdio.h>

int main(){
	
	printf("/**************************************************/\n");
	printf("/************* HUONG DAN CHEP TAP TIN *************/\n");
	printf("/=>B1. Vao thu muc \"C:\TUYENTAP\thotinh.txt\"        /\n");
	printf("/=>B2. Click chuot phai vao tap tin thotinh.txt    /\n");
	printf("/=>B3. Chon copy tu menu tat                       /\n");
	printf("/=>B4. Chon vi tri can luu, click phai chon paste  /\n");
	printf("/**************************************************/\n");
	
	return 0;
}
