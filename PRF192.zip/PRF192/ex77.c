#include <stdio.h>
#include <math.h>

void odd(int arr[], int n){	
	for(int i = 0; i < n; i++){
		if(arr[i] % 2 != 0){
			printf("%d ", arr[i]);
		}
	}
}

void even(int arr[], int n){	
	for(int i = 0; i < n; i++){
		if(arr[i] % 2 == 0){
			printf("%d ", arr[i]);
		}
	}
}

void enterArr(int arr[], int n){
	for(int i = 0; i < n; i++){
		printf("Enter the %d element: ", i + 1);
		scanf("%d", &arr[i]);
	}
	
	printf("Array:\n");
	for(int i = 0; i < n; i++){
		printf("%d ", arr[i]);
	}
}

int main(){
	int n;
	
	printf("Enter number of elements: ");
    while (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid input. Array must have at least 1 value. Try again.\n");
        printf("Enter number of elements: ");
        while (getchar() != '\n');
    }
    
    int arr[n];
    enterArr(arr, n);
    printf("\nOdd array:\n");
    odd(arr, n);
    printf("\nEven array:\n");
    even(arr, n);
    
	return 0;
}
