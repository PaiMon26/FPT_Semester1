#include <stdio.h>
#include <math.h>

int isPrime(int n){

	for(int i = 2; i <= sqrt(n); i++){
		if(n % i == 0){
			return 0;
		}
	}
	return 1;
}


int main(){
	
	int a, b;
	
	printf("Enter the first number: ");
	scanf("%d", &a);
	printf("Enter the last number: ");
	scanf("%d", &b);
		
	if(a == b){
		printf("Invalid value.\n");
		return 0;
	}
	
	if(a > b){
		int temp = a;
		a = b;
		b = temp;
	}
	
	printf("Prime numbers between %d and %d are: ", a, b);
	for(int i = a; i <= b; i++){
		if(isPrime(i)){
			printf("%d ", i);
		}
	}
	
	return 0;
}
