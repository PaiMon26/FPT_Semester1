#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isvowel(char ch){
	ch = toupper(ch);
	return(ch == 'A' || ch == 'E' || ch == 'U' || ch == 'O' || ch == 'I');
}

int isconsonant(char ch){
	ch = toupper(ch);
	return(isalpha(ch) && !isvowel(ch));
}

int main(){
	char str[100];
	int vowel = 0, consonant = 0, other = 0;
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	for (int i = 0; i < sizeof(str); i++){
		if (isalpha(str[i])){
			if (isvowel(str[i])){
				vowel++;
			}
			else if (isconsonant(str[i])){
				consonant++;
			}
			else{
				other++;
			}
		}
		else{
			other++;
		}
	}
	
	printf("Number of vowels: %d\n", vowel);
	printf("Number of consonants: %d\n", consonant);
	
	getchar();
	return 0;
}
