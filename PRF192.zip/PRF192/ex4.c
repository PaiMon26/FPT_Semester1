#include <stdio.h>
#include <math.h>

int main(){
	
	int n1;
	int n2;
	int sum;
	
	printf("Enter first interger number: ");
	scanf("%d", &n1);
	printf("\nEnter second interger number: ");
	scanf("%d", &n2);
	
	sum = n1 + n2;
	
	printf("The sum is: %d", sum);
	
	return 0;
}
