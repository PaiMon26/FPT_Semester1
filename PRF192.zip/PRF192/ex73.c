#include <stdio.h>
#include <math.h>

int isPrime(n){
	for(int i = 2; i <= sqrt(n); i++){
		if(n % i == 0){
			return 0;
		}
	}
	return 1;
}

int sum(int arr[], int n){
	int sum = 0;	
	for(int i = 0; i < n; i++){
		if(isPrime(arr[i]))
			sum += arr[i];
	}
	return sum;
}

void enterArr(int arr[], int n){
	for(int i = 0; i < n; i++){
		printf("Enter the %d element: ", i + 1);
		scanf("%d", &arr[i]);
	}
	
	printf("Array:\n");
	for(int i = 0; i < n; i++){
		printf("%d ", arr[i]);
	}
}

int main(){
	int n;
	
	printf("Enter number of elements: ");
    while (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid input. Array must have at least 1 value. Try again.\n");
        printf("Enter number of elements: ");
        while (getchar() != '\n');
    }
    
    int arr[n];
    enterArr(arr, n);
    int s = sum(arr, n);
    printf("\nSum of prime numbers = %d", s);
    
	return 0;
}
