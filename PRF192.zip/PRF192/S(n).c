// S(n)=1+3+5+?.+(2�n+1),       n>=0

#include <stdio.h>
#include <math.h>

int main(){
	
	int n, S, i;
	S = 0;
	i = 1;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	if (n < 0){
		printf("Invalid value, n >= 0");
	}
	else{
		for(i; i <= n; i += 2){
			S = S + i;
		}
	printf("S = %d", S);
	}
	
	return 0;
}
