#include <stdio.h>
#include <math.h>

int main(){
	
	int n, i, m, S;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	i = 1;
	S = 0;
	m = 1;
	
	if(n <= 0){
		printf("Invalid value, n > 0\n");
	}
	else{
		while(i <= n){
			S = S + m;
			i = i + 1;
			m = pow(-1, (i + 1)) * i;
		}
		printf("S = %d", S);
	}
	
	return 0;
}
