#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void reverseWords(char* str) {
    int len = strlen(str);
    char *temp = (char*)malloc(len + 1);
    strcpy(temp, str);

    char *words[100]; 
    int count = 0;
    
    char *token = strtok(temp, " ");
    while (token != NULL) {
        words[count] = token;
        count++;
        token = strtok(NULL, " ");
    }

    int index = 0;
    for (int i = count - 1; i >= 0; i--) {
        strcpy(str + index, words[i]);
        index += strlen(words[i]);
        if (i > 0) {
            str[index] = ' ';
            index++;
        }
    }
    str[index] = '\0';

    free(temp);
}

int main() {
    char str[100];

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    str[strcspn(str, "\n")] = '\0';

    reverseWords(str);

    printf("String after reversing words: %s\n", str);

    return 0;
}

