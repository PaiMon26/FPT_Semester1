#include <stdio.h>

int main(){
	
	int a, b;
	
	printf("Enter a: ");
	scanf("%d", &a);
	printf("Enter b: ");
	scanf("%d", &b);
	
	if(a>=b){
		printf("The maximum value is: %d\n",a);
	}
	else{
		printf("The maximum value is: %d\n",b);
	}
	
	
	return 0;
}
