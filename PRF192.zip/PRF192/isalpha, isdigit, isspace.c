#include <stdio.h>
#include <string.h>
#include <ctype.h>

void total(char *str, int *alphabets, int *digits, int *special){
	*alphabets = 0;
	*digits = 0;
	*special = 0;
	
	while (*str){
		if (isalpha(*str)){
			(*alphabets)++;
		} 
		else if (isdigit(*str)){
			(*digits)++;
		}
		else if (!isspace(*str)){
			(*special)++;
		}
		str++;
	}
}

int main(){
	char str[100];
	int alphabets, digits, special;
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	total(str, &alphabets, &digits, &special);
	
	printf("Number of alphabets: %d\n", alphabets);
	printf("Number of digits: %d\n", digits);
	printf("Number of special characters: %d\n", special);
	
	getchar();
	return 0;
}
