#include <stdio.h>
#include <math.h>

int isPerfectSquare(int n){
	int sqrt_val = sqrt(n);
	return (sqrt_val * sqrt_val == n);
}


void printPerfectSquare(int arr[], int n){
	
	printf("Perfect Square numbers in array: ");
	for(int i = 0; i < n; i++){
		if(isPerfectSquare(arr[i])){
			printf("%d ", arr[i]);
		}
	}
}


int main(){
	int n;
	
	do{
		printf("Enter number of elements: ");
		scanf("%d", &n);
		
		if(n <= 0){
			printf("Array must have at least 1 value. Try again.\n");
		}
	}
	while(n <= 0);
	
	int arr[n];
	
	for(int i = 0; i < n; i++){
		printf("Enter the %d element: ", i + 1);
		scanf("%d", &arr[i]);
	}
	
	printPerfectSquare(arr, n);
	
	return 0;
}
