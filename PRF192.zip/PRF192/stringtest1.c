#include <stdio.h>
#include <conio.h>

int main(){
	char s[11] = "Hello";
	printf(s);
	getch();
	return 0;
}
