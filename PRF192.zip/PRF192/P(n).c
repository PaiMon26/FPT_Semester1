#include <stdio.h>
#include <math.h>

int main(){
	
	int n, P, i;
	P = 1;
	i = 1;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	if (n < 0){
		printf("Invalid value, n >= 0");
	}
	else{
		for(i; i <= n; i += 2){
			P = P * i;
		}
	printf("P = %d", P);
	}
	
	return 0;
}
