#include <stdio.h>
#include <math.h>

int main(){
	
	int n, i, p, S;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	i = 1;
	p = 1;
	S = 0;
	
	if(n <= 0){
		printf("Invalid value, n > 0\n");
	}
	else{
		while(i <= n){
			p = p * i;
			S = S + p;
			i = i + 1;
		}
		printf("S = %d", S);
	}
	
	return 0;
}
