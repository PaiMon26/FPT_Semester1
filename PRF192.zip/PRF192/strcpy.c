#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(){
	char c1[100];
	char c2[100];
	
	printf("Enter a string: ");
	fgets(c1, sizeof(c1), stdin);
	c1[strcspn(c1, "\n")] = '\0';
    printf("\n");
    
	strcpy(c2, c1);
	
	printf("Source string: %s\n", c1);
	printf("Copied string: %s\n", c2);
	
	getchar();
	return 0;
}

