#include <stdio.h>
#include <math.h>

int main(){
	
	int n1, n2, modulus, sum, different, product, quotient;
	
	printf("Enter first interger number: ");
	scanf("%d", &n1);
	printf("\nEnter second interger number: ");
	scanf("%d", &n2);
	
	sum = n1 + n2;
	different = n1 - n2;
	product = n1 * n2;
	quotient = n1 / n2;
	modulus = n1 % n2;
	
	printf("\nThe sum is: %d", sum);
	printf("\nThe different is: %d", different);
	printf("\nThe product is: %d", product);
	printf("\nThe quotient is: %d", quotient);
	printf("\nThe modulus is: %d", modulus);
	
	return 0;
}
