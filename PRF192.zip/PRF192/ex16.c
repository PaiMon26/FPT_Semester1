#include <stdio.h>
#include <math.h>

void triangle(){
	
	float a, b, c, d, p, s;
	
	printf("Enter the length of the first the side: ");
	scanf("%f", &a);
	printf("Enter the length of the second the side: ");
	scanf("%f", &b);
	printf("Enter the length of the third the side: ");
	scanf("%f", &c);
	
	p = a + b + c;
	d = p / 2;
	s = sqrt(p * (p - a) * (p - b) * (p - c));
	
	printf("The perimeter of the triangle is: %.2f\n", p);
	printf("The area of the triangle is: %.2f\n", s);
	
}

void square(){
	
	float a, p, s;
	
	printf("Enter the square\'s side: ");
	scanf("%f", &a);
	
	p = a * 4;
	s = a * a;
	
	printf("The perimeter of the square is: %.2f\n", p);
	printf("The area of the square is: %.2f\n", s);
}

void rectangle(){
	
	float a, b, p, s;
	
	printf("Enter the length of the rectangle: ");
	scanf("%f", &a);
	printf("Enter the width of the rectangle: ");
	scanf("%f", &b);
	
	p = (a + b) * 2;
	s = a * b;
	
	printf("The perimeter of the rectangle is: %.2f\n", p);
	printf("The area of the rectangle is: %.2f\n", s);
}

void circle(){
	
	float r, p, s;
	
	printf("Enter the radius of the circle: ");
	scanf("%f", &r);
	
	p = r * 2 * M_PI;
	s = r * r * M_PI;
	
	printf("The perimeter of the circle is: %.2f\n", p);
	printf("The area of the circle is: %.2f\n", s);
}

int main(){
	
	int choice;
	
	while(1){
		
		printf("Choose a shape to calculate:\n");
		printf("1. Triangle\n");
		printf("2. Square\n");
		printf("3. Rectangle\n");
		printf("4. Circle\n");
		printf("5. Exit\n");
		
		printf("Enter your choice (1-5): ");
		scanf("%d", &choice);
		
		switch(choice){
			
			case 1:
				triangle();
				break;
			case 2:
				square();
				break;
			case 3:
				rectangle();
				break;
			case 4:
				circle();
				break;
			case 5:
				printf("Exit the program. Goodbye!");
				return 0;
			default:
				printf("Invalid choice. Please enter again.");
				
		}
	}
	
	return 0;
}
