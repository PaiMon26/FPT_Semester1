#include <stdio.h>
#include <math.h>

int Maximum(int numbers[], int count){
	
	int max = numbers[0];
	
	for(int i = 1; i < count; i++){
		if (numbers[i] > max){
			max = numbers[i];
		}
	}

	return max; 
}


int Minimum(int numbers[], int count){
	
	int min = numbers[0];
	
	for(int i = 1; i < count; i++){
		if(numbers[i] < min){
			min = numbers[i];
		}
	}
	
	return min;
}


int main(){
	
	int count;
	
	printf("Enter number of elements: ");
	scanf("%d", &count);
	
	if(count < 2){
		printf("Please enter at least two numbers.\n");
		return 1;
	}
	
	int numbers[count];
	
	printf("Enter elements:\n");
	for(int i = 0; i < count; i++){
		scanf("%d", &numbers[i]);
	}
	
	int max = Maximum(numbers, count);
	int min = Minimum(numbers, count);
	
	printf("max = %d\n", max);
	printf("min = %d\n", min);
	
	return 0;
}
