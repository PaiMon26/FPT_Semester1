#include <stdio.h>

int main(){
	
	char al;
	
	printf("Enter an alphabet: ");
	scanf("%c", &al);
	
	switch (al){
		case 'u':
		case 'e':
		case 'o':
		case 'a':
		case 'i':
			printf("\'%c\' is vowel", al);
			break;
		default:
			printf("'%c' is consonant", al);
	}
	
	return 0;
}
