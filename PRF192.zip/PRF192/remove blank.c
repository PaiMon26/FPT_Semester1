#include <stdio.h>
#include <ctype.h>
#include <string.h>

void remove_blank(char str[]){
	int n = strlen(str);
	int i, j = 0;
	int inword = 0;
	
	for (i = 0; i < n; i++){
		if (!isspace(str[i])){
			break;
		}
	}
	
	for (; i < n; i++){
		if (isspace(str[i])){
			if (inword){
				str[j++] = ' ';
				inword = 0;
			}
		}
		else{
			str[j++] = str[i];
			inword = 1;
		}
	}
	
	if (j > 0 && str[j - 1] == ' ') {
        j--;
    }
    
	str[j] = '\0';
}

int main(){
	char str[100];
	char n, m;
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	remove_blank(str);
	printf("Modified string: %s", str);
		
	return 0;
}
