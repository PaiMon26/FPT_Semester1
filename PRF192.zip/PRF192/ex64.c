#include <stdio.h>
#include <math.h>

int isEven(int n){
	
	if(n % 2 != 0){
		return 0;
	}
	
	return 1;
}


int countEven(int arr[], int n){
	int count = 0;
	
	for(int i = 0; i < n; i++){
		if(isEven(arr[i])){
			count += 1;
		}
	}
	
	return count;
}


int main(){
	int n, count;
	
	do{
		printf("Enter number of elements: ");
		scanf("%d", &n);
		
		if(n <= 0){
			printf("Array must have at least 1 value. Try again.\n");
		}
	}
	while(n <= 0);
	
	int arr[n];
	
	for(int i = 0; i < n; i++){
		printf("Enter the %d elements: ", i + 1);
		scanf("%d", &arr[i]);
	}
	
	count = countEven(arr, n);
	
	printf("Number of even numbers is: %d", count);
	
	return 0;
}
