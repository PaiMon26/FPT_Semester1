#include<stdio.h>

int main(int n){
	
	int n1, n2, sum;
	
	printf("Enter a two digits interger: ");
	scanf("%d", &n);
	
	if (n<10 || n>99){
		
		printf("Please enter a two digits number!");
		
	}
	else{
		
		n1 = n/10;
		n2 = n%10;
		sum = n1 + n2;
		
		printf("Sum of two digits is: %d", sum);
		
	}
	
return 0;
}
