#include <stdio.h>
#include <math.h>

int main(){
	
	int n, m, i;
	m = 1;
	i = 1;
	
	printf("Enter n: ");
	scanf("%d", &n);
	
	if (n <= 0){
		printf("Invalid value, n > 0");
	}
	else{
		while(i <= n){
		m *= i;
		i++;
	}
	
	printf("%d! = %d ",n , m);
	}
	
	return 0;
}
