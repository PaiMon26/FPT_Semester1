#include <stdio.h>
#include <string.h>
#include <ctype.h>

void reverse(char str[]){
	int n = strlen(str);
	char temp;
	
	for (int i = 0; i < n / 2; i++){
		temp = str[i];
		str[i] = str[n - 1 - i];
		str[n - 1 - i] = temp;
	}
	
}


int main(){
	char str[100];
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	strrev(str);
	
	//reverse(str);
	printf("String after reverse: %s", str);
	
	return 0;
}
