#include <stdio.h>
#include <string.h>
#include <ctype.h>

int lowest_freq(char str[]){
	int count[256] = {0};
	int min_freq = 256;
	char min_char = '\0';
	
	for (int i = 0; str[i] != '\0'; i++){
		count[str[i]]++;
	}
	
	for (int i = 0; i < 256; i++){
		if (count[i] > 0 && count[i] < min_freq){
			min_freq = count[i];
			min_char = (char)i;
		}
	}
	
	return min_char;
}


int main(){
	char str[100];
	
	printf("Enter a string: ");
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = '\0';
	
	char min_char = lowest_freq(str);
	printf("The lowest frequency character is '%c'.\n", min_char);
	
	return 0;
}
