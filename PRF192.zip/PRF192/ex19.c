#include <stdio.h>

int main(){
	
	int a;
	
	printf("Enter a: ");
	scanf("%d", &a);
	
	if(a>0){
		printf("%d is positive\n",a);
	}
	else if(a<0){
		printf("%d is negative\n",a);
	}
	else{
		printf("a = 0\n");
	}	
	
	return 0;
}
