#include <stdio.h>
#include <math.h>

int perfectCheck(int n){
	
	int s = 1;
	
	for(int i = 2; i < sqrt(n); i++){
		if(n % i == 0){
			if(i == (n / i)){
				s += i;
			}
			else{
				s += i + (n / i);
			}
		}
	}
	
	return s;
}


int main(){
	
	int n;
	
	printf("Enter a number: ");
	scanf("%d", &n);
	
	if(n > 1 && perfectCheck(n) == n){
		printf("%d is a perfect number.\n", n);
	}
	else{
		printf("%d is not a perfect number.\n", n);
	}
	
	return 0;
}
