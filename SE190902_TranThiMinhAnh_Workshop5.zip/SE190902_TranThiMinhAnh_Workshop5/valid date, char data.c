#include <stdio.h>
#include <math.h>

int leap_year(int year) {
    if (year % 4 == 0) {
        if (year % 100 == 0) {
            if (year % 400 == 0)
                return 1; 
            else
                return 0; 
        } else {
            return 1; 
        }
    } else {
        return 0; 
    }
}


int valid_date(int day, int month, int year){
	if (day < 1 || day > 31) 
		return 0;
	switch (month){
		case 1: 
		case 3: 
		case 5: 
		case 7: 
		case 8: 
		case 10: 
		case 12:
			return (day <= 31);
		case 4: 
		case 6: 
		case 9: 
		case 11:
			return (day <= 30);
		case 2:
			if (leap_year(year)) 
				return (day <= 29);
			else 
				return (day <= 28);
		default: 
			return 0;
	}
}

void char_data(char c1, char c2){
	int temp;
	
	if (c2 > c1){
		temp = c1;
		c1 = c2;
		c2 = temp;
	}
	for (int i = c1; i >= c2; i--){
		printf("%c: %3d, %3Xh\n", i, i, i);
	}
}

int main(){
	int day, month, year;
	char c1, c2;
	int choice;
	
	printf("1- Processing date data\n");
	printf("2- Character data\n");
	printf("3- Quit\n");

	do{
		printf("Choose your operation: ");
		scanf("%d", &choice);
		fflush(stdin);
		switch (choice){
			case 1:
				printf("Enter a day: ");
				scanf("%d", &day);
				fflush(stdin);
				printf("Enter a month: ");
				scanf("%d", &month);
				fflush(stdin);
				printf("Enter a year: ");
				scanf("%d", &year);
				fflush(stdin);
				
				if (valid_date(day, month, year)){
					printf("%d/%d/%d is a valid day.", day, month, year);
				}
				else{
					printf("%d/%d/%d is not a valid day.", day, month, year);
				}
				break;
			case 2:
				printf("Enter the first character: ");
				scanf("%c", &c1);
				fflush(stdin);
				printf("Enter the second character: ");
				scanf("%c", &c2);
				fflush(stdin);
				char_data(c1, c2);
				break;
			case 3:
				printf("Exit the program. Goodbye!\n");
				break;
			default:
				printf("Invalid value. Enter again: ");
		}
	} while (choice != 3);
	
	return 0;
}
