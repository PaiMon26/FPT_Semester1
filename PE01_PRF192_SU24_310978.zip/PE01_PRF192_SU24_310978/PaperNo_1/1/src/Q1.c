#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//------------------------------------------
void printVolume(int radius, int height ) {
	double S, V;
	double r = radius;
	double h = height;
	S = 3.14 * r * r;
	V = S * h;
	printf("%.2lf", V);

}
int main() {
	//=============DO NOT ADD NEW OR CHANGE THIS STATEMENTS========
	system("cls");
	printf("\nTEST Q1 (2 marks):\n");
	int r, h;
	double check;
	do {
		printf("Enter radius and height of cylinder: ");
		scanf("%d%d",&r, &h);
	} while((r<=0) || (h<=0));
	printf("\nOUTPUT:\n");
	printVolume(r, h);
	printf("\n");
	system ("pause");
	return(0);
	//============================================================
}

